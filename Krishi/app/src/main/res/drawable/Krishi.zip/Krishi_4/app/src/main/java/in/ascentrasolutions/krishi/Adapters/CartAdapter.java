package in.ascentrasolutions.krishi.Adapters;

public class CartAdapter {
}
