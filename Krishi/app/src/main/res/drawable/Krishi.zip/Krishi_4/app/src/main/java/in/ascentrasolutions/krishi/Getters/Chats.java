package in.ascentrasolutions.krishi.Getters;

public class Chats {

    private final String left, right;


    public String getLeft() {
        return left;
    }

    public String getRight() {
        return right;
    }

    public Chats(String left, String right) {
        this.left = left;
        this.right = right;
    }
}
