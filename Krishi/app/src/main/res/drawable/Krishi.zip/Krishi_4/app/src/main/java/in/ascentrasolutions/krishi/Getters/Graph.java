package in.ascentrasolutions.krishi.Getters;

public class Graph {

}
